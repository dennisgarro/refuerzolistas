import java.util.Stack;
public class Main{
    public static void main(String[] args) {
        Ejercicio6 ej = new Ejercicio6();
        int[][] matriz = new int[3][2];
       matriz = ej.llenar_matriz();
        ej.mostrarMatriz(matriz);
        ej.sumar_filas_promedios(matriz);

        Stack<Double> pilaP = new Stack<>();
        pilaP = ej.sumar_filas_promedios(matriz);
        ej.sumar_filas_promedios(matriz);
        ej.mostrarPilap(pilaP);

        Stack<Double> pilaR = new Stack<>();
        pilaR = ej.sumar_columnas_raices(matriz);
        ej.sumar_columnas_raices(matriz);
        ej.mostrarPilar(pilaR);

        Stack<Integer> pilaM = new Stack<>();
        pilaM = ej.multiplicarMatriz(matriz);
        ej.mostrarPilam(pilaM);}       
}