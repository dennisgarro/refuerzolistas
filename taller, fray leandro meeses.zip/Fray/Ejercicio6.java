import java.util.Stack;

public class Ejercicio6 {

    public int[][] llenar_matriz(){
            int[][] pongame5 = new int[3][2]; // ahi dice n*m, de gracias que no lo puse 1*2
            for (int i = 0; i < pongame5.length; i++) {
                for (int j = 0; j < pongame5[i].length; j++) {
                    pongame5[i][j] = (int) (Math.random() * 100); 
            }
        }
        return pongame5;
    }

        public void mostrarMatriz(int[][] pongame5) {
           System.out.println("*su matriz es*: ");
           System.out.println();
            for (int i = 0; i < pongame5.length; i++) {
                for (int j = 0; j < pongame5[i].length; j++) {
                   
                    System.out.print( "[" + pongame5[i][j] +"]");
                }   
                System.out.println(); 
        }
    }

     public Stack<Double> sumar_filas_promedios(int[][] pongame5) {
        Stack<Double> pilaPromedios = new Stack<>();
        Stack<Double> pilaPromediosFinal = new Stack<>();

        for (int i = 0; i < pongame5.length; i++) {
            int sumaFila = 0;

            for (int j = 0; j < pongame5[i].length; j++) {
                sumaFila += pongame5[i][j];
            }
            double promedio = (double) sumaFila / pongame5[i].length;

            pilaPromedios.push(promedio);
     
        }

        while (!pilaPromedios.isEmpty()) {
            pilaPromediosFinal.push(pilaPromedios.pop());
        }
        return pilaPromediosFinal;
    }

    public void mostrarPilap(Stack<Double> pila) {
        System.out.println("\nLos promedios de las sumas de filas son:");
        while (!pila.isEmpty()) {
            System.out.println(pila.pop());
        }
    }

    public Stack<Double> sumar_columnas_raices(int[][] pongame5) {
        int columnas = pongame5[0].length;
        Stack<Double> pilaRaices = new Stack<>();
        Stack<Double> pilaRaicesFinal = new Stack<>();

        for (int j = 0; j < columnas; j++) {
            int sumaColumna = 0;
            for (int[] fila : pongame5) {
                sumaColumna += fila[j];
            }

            double raiz = Math.sqrt(sumaColumna);
            pilaRaices.push(raiz);
        }

        while (!pilaRaices.isEmpty()) {
            pilaRaicesFinal.push(pilaRaices.pop());
        }

        return pilaRaicesFinal;
    }

    public void mostrarPilar(Stack<Double> pila) {
        System.out.println("\nlas raises de las sumas de columnas son :");
        while (!pila.isEmpty()) {
            System.out.println(pila.pop());
        }
    }

    public Stack<Integer> multiplicarMatriz(int[][] pongame5) {
        Stack<Integer> pilaResultadoM = new Stack<>();

        
        for (int i = 0; i < pongame5.length; i++) {
            for (int j = 0; j < pongame5[i].length; j++) {
                int resultado = pongame5[i][j] * pongame5[i][j];  // Multiplicar el elemento por sí mismo
                pilaResultadoM.push(resultado);  // Guardar el resultado en la pila
            }
        }

        return pilaResultadoM; 
    }

    public void mostrarPilam(Stack<Integer> pila) {
        System.out.println("\nResultado de la multiplicación :");
        while (!pila.isEmpty()) {
            System.out.println(pila.pop());
        }


   
}}





